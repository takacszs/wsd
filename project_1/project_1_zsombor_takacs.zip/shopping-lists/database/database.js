import { postgres } from "../deps.js"

const sql = postgres({});

export { sql };