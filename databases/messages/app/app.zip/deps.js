export { serve } from "https://deno.land/std@0.171.0/http/server.ts";
import postgres from "https://deno.land/x/postgresjs@v3.3.3/mod.js";
export { postgres };
