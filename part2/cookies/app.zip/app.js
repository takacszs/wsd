import { Application, Router } from "https://deno.land/x/oak@v11.1.0/mod.ts";
import { Session } from "https://deno.land/x/oak_sessions@v4.0.5/mod.ts";

const app = new Application();
app.use(Session.initMiddleware())
const router = new Router();

const get = async ({ response, state }) => {
  let name = await state.session.get("name");
  console.log(name)
  if(name) response.body = `Hello ${name}!`
  else response.body = "Hello anonymous!"
};

const set = async ({  request, response, state }) => {
  const body = request.body();
  const params = await body.value;
  await state.session.set("name", params.get("name"));
  response.redirect("/")
};

router.post("/", set)
router.get("/", get)

app.use(router.routes());

if (!Deno.env.get("TEST_ENVIRONMENT")) {
  app.listen({ port: 7777 });
}

export default app;
